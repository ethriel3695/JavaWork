package animalActions;

import java.util.*;

/*
 * @author Reuben Ellis
 * Date: 2016-07-24
 * Revised: 2016-07-31
 * ArrayList Animal Interaction for PRG/421
 * The AnimalInteraction class provides a scanner property to get user inputs
 * and assign the values respectively.  
 * An ArrayList is used to hold the name values of the animal classes.

 * The select method accepts only an existing name from within the wildlife 
 * reserve and if the name exists will display the traits of the animal to the 
 * user.

 * The add method allows a user to choose whether they want to add an animal
 * and the animal is then added to either the mammal, bird, or reptile class
 * based on the unique trait value entered.  The user must enter a name, color,
 * unique identifier, and the number of legs for the animal.

 * The edit method allows a user to enter the name of an existing animal to
 * edit either the color of the animal or the number of legs.  The name is 
 * unique to the animal and cannot be entered. Also, the unique identifier 
 * dictates what type the animal is so this property cannot be changed either.

 * The delete method allows a user to enter an existing animal name for deletion
 * and then deletes the animal from the wildlife reserve.  If the user deletes
 * all animals, the user will get a message when trying to delete another 
 * animal, stating no animals exist in the wildlife reserve.
 */
public class AnimalInteraction {
    
    private static Scanner 
        userInput = new Scanner(System.in);
    
    private static ArrayList<String>
        animalList = new ArrayList<String>(),
        animalUniqueTrait= new ArrayList<String>();
    
    private static LinkedHashMap<String, Animal>
        animalObject = new LinkedHashMap<String, Animal>();
    
    private static ArrayList<Animal>
        animal = new ArrayList<Animal>();
    
    private static String
        input = "",
        animalNameInput = "";
    
    private static Boolean
        inputValue = false;
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        animalUniqueTrait.add("hair");
        animalUniqueTrait.add("feathers");
        animalUniqueTrait.add("coldBlood");
        
        animalObject.put("Panther", new Animal("Panther", "black", "hair", "4"));
        animalObject.put("Falcon", new Animal("Falcon", "grey and black",
                "feathers", "2"));
        animalObject.put("Tortoise", new Animal("Tortoise", "yellowish", 
                "coldBlood", "4"));
        
        animal = new ArrayList<Animal>(animalObject.values());
        
        for (Animal animalName : animal)
        {
            animalList.add(animalName.animalName());
        }
        
        do
        {
            String
                    userResponse = "";
            welcomePrompt();
            userResponse = validateUserOption();

            if (userResponse.equalsIgnoreCase("select"))
            {
                selectAnimalAttributes();
            }
            else if (userResponse.equalsIgnoreCase("add"))
            {
                addNewAnimal();
            }
            else if (userResponse.equalsIgnoreCase("edit"))
            {
                editExistingAnimal();
            }
            else if (userResponse.equalsIgnoreCase("delete"))
            {
                deleteExistingAnimal();
            }

            System.out.println("Please enter quit to end the program "
                    + "\nor anything else to continue: ");
            input = userInput.nextLine();
            
        }while (!input.equalsIgnoreCase("quit"));
    }
    
    //Method which displays a welcome message to the user and displays the 
    //current animals within the wildlife reserve
    private static void welcomePrompt()
    {
        
        String
                welcomeMessage = "Welcome to the Animal Interaction Zone!"
                + "\nThe following animals are already in the wildlife reserve:"
                + "\n",
                optionsMessage = "\nPlease enter one of the following options: "
                + "select, add, edit, or delete.";
        
        Collections.sort(animalList);
        
        Object[] displayAnimals = animalList.toArray();
        
        System.out.println(welcomeMessage);
        for (Object animals : displayAnimals)
        {
            System.out.println(animals);
        }
        System.out.println(optionsMessage);
    }
    
    //A method to validate and return a value based on whether the user chose,
    //'select', 'add', 'edit', or 'delete'
    private static String validateUserOption()
    {
        String
                select = "select",
                add = "add",
                edit = "edit",
                delete = "delete";
        
        input = userInput.nextLine();
        while(!input.equalsIgnoreCase(select) && !input.equalsIgnoreCase(add) &&
                !input.equalsIgnoreCase(edit) && !input.equalsIgnoreCase(delete))
        {  
            System.out.println("Please enter either: select, add, edit,"
            + " or delete!");
            input = userInput.nextLine();
        }
        if (input.equalsIgnoreCase(select))
        {
            input = select;
        }
        else if (input.equalsIgnoreCase(add))
        {
            input = add;
        }
        else if (input.equalsIgnoreCase(edit))
        {
            input = edit;
        }
        else if (input.equalsIgnoreCase(delete))
        {
            input = delete;
        }
        return input;
    } 
    
    //Allows the user to get the attributes of an animal
    private static void selectAnimalAttributes()
    {   
        System.out.println("Enter an animal name already in the wildlife"
                + " reserve to see a full description: ");
        
        input = userInput.nextLine();
        do
        {
            if (animalList.isEmpty())
            {
                System.out.println("There are no longer any animals in the"
                        + " wildlife reserve.");
                break;
            }
                        
            checkAnimalExists();
            
            for (Animal inputAnimal : animal)
            {
                if (inputAnimal.animalName().equalsIgnoreCase(animalNameInput))
                {
                    System.out.println("Animal Color: " 
                        + inputAnimal.animalColor() + "\nUnique Animal Trait: " 
                        + inputAnimal.uniqueAnimalTrait()
                        + "\nNumber of Legs Animal has: " 
                            + inputAnimal.numberOfLegs());
                }
            }
        System.out.println("\nPlease enter done to return to the main page "
            + "\nor an animal name for details: ");
        input = userInput.nextLine();
        
        }while (!input.equalsIgnoreCase("done"));
    }
    
    //Allows the user to add an animal to the reserve
    private static void addNewAnimal()
    {
        String
                name = "",
                color = "",
                uniqueTrait = "",
                legs = "";
        
        System.out.println("Do you want to add an animal to the reserve? Enter "
                + "'yes' or 'no'");
        input = userInput.nextLine();
        do
        {
            while (!input.equalsIgnoreCase("yes") && !input.equalsIgnoreCase("no"))
            {
                System.out.println("Please enter 'yes' or 'no' to continue: ");
                input = userInput.nextLine();
            }
            if (input.equalsIgnoreCase("yes"))
            {
                System.out.println("Enter the following information to add an "
                + "animal to the wildlife reserve: ");
                System.out.println("Animal Name: ");
                input = userInput.nextLine();
                name = input;
                System.out.println("Animal Color: ");
                input = userInput.nextLine();
                color = input;
                System.out.println("Enter either 'hair' for a mammal, "
                    + "'feathers' for a bird, or 'coldBlood' for a reptile: ");
    
                input = userInput.nextLine();

                uniqueTrait = input;

                while (!input.equalsIgnoreCase("hair") && 
                        !input.equalsIgnoreCase("feathers") && 
                        !input.equalsIgnoreCase("coldBlood"))
                {
                    System.out.println("\nPlease enter either hair, feathers, "
                            + "or coldBlood: ");
                    input = userInput.nextLine();
                }
                System.out.println("Number of Legs: ");
                input = userInput.nextLine();
                legs = input;
        
                for (String animalTrait : animalUniqueTrait)
                {
                    if (animalTrait.equalsIgnoreCase(uniqueTrait))
                    {
                        animalObject.put(name, new Animal(name, color, 
                                uniqueTrait, legs));
                        
                        animal = new ArrayList<Animal>(animalObject.values());

                        animalList.add(name);
                    }
                }
            }
            else if (input.equalsIgnoreCase("no"))
            {
                break;
            }
        System.out.println("\nPlease enter done to return to the main page "
        + "\nor anything else to continue: ");
        input = userInput.nextLine();
        
        }while (!input.equalsIgnoreCase("done"));
    }
    
    //Allows the user to edit certain characteristics of an animal
    private static void editExistingAnimal()
    {
        String
                animalName = "",
                color = "",
                legs = "";
        
        System.out.println("Enter the name of an animal"
        + " from the wildlife reserve to change an attribute: ");
        
        input = userInput.nextLine();
        do
        {
            if (animalList.isEmpty())
            {
                System.out.println("There are no animals in the"
                        + " wildlife reserve.");
                break;
            }
            
            checkAnimalExists();
            
            for (Animal inputAnimal : animal)
            {
                if (inputAnimal.animalName().equalsIgnoreCase(animalNameInput))
                {
                if (animalList.contains(animalNameInput))
                {
                    System.out.println("Please enter either 'color' or 'legs' "
                            + "to change the color or number of legs for the "
                            + "animal");
                    input = userInput.nextLine();
                    
                    while(!input.equalsIgnoreCase("color") 
                            && !input.equalsIgnoreCase("legs"))
                    {
                        System.out.println("Please enter either 'color' or "
                                + "'legs' to continue: ");
                        input = userInput.nextLine();
                    }
                    
                    if (input.equalsIgnoreCase("color"))
                    {
                        System.out.println("Enter a new color: ");
                        input = userInput.nextLine();
                        if (inputAnimal.animalName().equalsIgnoreCase(animalNameInput))
                        {
                            inputAnimal.changeAnimalColor(input);
                            System.out.println(animalNameInput 
                                    + " color updated!");
                        }
                    }
                    else if (input.equalsIgnoreCase("legs"))
                    {
                        System.out.println("Enter a new number of legs: ");
                        input = userInput.nextLine();
                        if (inputAnimal.animalName().equalsIgnoreCase(animalNameInput))
                        {
                            inputAnimal.changeLegCount(input);
                            System.out.println(animalNameInput + " number of legs"
                                    + " updated!");
                        }
                    }
                }
                else
                {
                    System.out.println("\nAnimal does not exist!!!");
                }
                }
            }
        System.out.println("\nPlease enter done to return to the main page "
            + "\nor an animal name for editing: ");
        input = userInput.nextLine();
        
        }while (!input.equalsIgnoreCase("done"));
    }
    
    //Allows the user to delete an animal from the reserve
    private static void deleteExistingAnimal()
    {
        System.out.println("Enter the name of the animal being removed"
        + " from the wildlife reserve: ");
        
        input = userInput.nextLine();
        do
        {
            if (animalList.isEmpty())
            {
                System.out.println("There are no longer any animals in the"
                        + " wildlife reserve.");
                break;
            }
        
        checkAnimalExists();
        
        for (Animal inputAnimal : animal)
        {
            if (inputAnimal.animalName().equalsIgnoreCase(animalNameInput))
            {
                if (animalList.contains(animalNameInput))
                {
                    animalList.remove(animalNameInput);
                    animalObject.remove(animalNameInput);
                    animal = new ArrayList<Animal>(animalObject.values());
                    System.out.println("Animal has been removed!");
                }
                else
                {
                    System.out.println("\nAnimal does not exist!!!");
                }
            }
        }
        System.out.println("\nPlease enter done to return to the main page "
            + "\nor an animal name for removal: ");
        input = userInput.nextLine();
        
        }while (!input.equalsIgnoreCase("done"));
    }
    
    private static void checkAnimalExists()
    {
        for (String name : animalList)
        {
            if (input.equalsIgnoreCase(name))
            {  
                inputValue = true;
                animalNameInput = name;
                break;
            }
            else
            {
                inputValue = false;
            }
        }
    
        if (inputValue == false)
        {
            System.out.println("\n" + (char)27 + 
                    "[31m" + "The Animal Does not exist!" 
                    + ": " + (char)27 + "[0m");
            animalNameInput = "";
        }   
    }
    
}
